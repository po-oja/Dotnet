﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_loan
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the customername");
            string name = Console.ReadLine();
            Console.WriteLine("enter the customeremailid");
            string  email = Console.ReadLine();
            Console.WriteLine("enter the customermobile");
            string phoneno = Console.ReadLine();

            Console.WriteLine("enter the Loan amount");
            int loan = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the duration");
            int time = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the rate");
            int rate = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the type of account");
            string type = Console.ReadLine();

            Loan l = null;
            if (type == "homeloan")
            {
                l = new home_loan(name, email,phoneno,loan,time,rate);
            }
            else if (type =="vehicleloan")
            {
                l= new vehicle_loan(name, email, phoneno, loan, time, rate);
            }

            if (l != null)
            {
                Console.WriteLine(l.ploanid);
                Console.WriteLine(l.pcustomername);
                Console.WriteLine(l.pcustomeremail);
                Console.WriteLine(l.pcustomermobile);
                Console.WriteLine(l.ploanamt);
                Console.WriteLine(l.pduration);
                Console.WriteLine(l.prate);
                Console.WriteLine("enter the principle amount");
                int amount = Convert.ToInt32(Console.ReadLine());

                int a = l.payEMI(amount);
                Console.WriteLine("monthly EMI is =" + a);
                int pend = l.getpendingloan();
                Console.WriteLine("The pending loan amount is=" + pend);
                Console.ReadLine();

            }







            }
        }
}

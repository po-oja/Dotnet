﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_loan
{
   abstract class Loan
    {
        protected int loanid;
        protected string customername;
        protected string customeremail;
        protected string customermobile;
        protected int loanamt;
        protected int duration;
        protected int rate;
        protected int a;
        protected static int count;

        public Loan(string customername,string customeremail,string customermobile,int loanamt,int duration,int rate)
        {
            this.loanid = ++Loan.count;
            this.customername = customername;
            this.customeremail = customeremail;
            this.customermobile = customermobile;
            this.loanamt = loanamt;
            this.duration = duration;
            this.rate = rate;
        }

        public int ploanid { get { return this.loanid; } }
        public string pcustomername { get { return this.customername; } }
        public string pcustomeremail { get { return this.customeremail; } }
        public string pcustomermobile { get { return this.customermobile; } }
        public int ploanamt { get { return this.loanamt; } }
        public int pduration { get { return this.duration; } }
        public float prate { get { return this.rate; } }

        public abstract int payEMI(int amount);

        public abstract int getpendingloan();
     











    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_loan
{
    class vehicle_loan:Loan
    {
       
            public vehicle_loan(string customername, string customeremail, string customermobile, int loanamt, int duration, int rate)
                : base(customername, customeremail, customermobile, loanamt, duration, rate)
            {
                Console.WriteLine("vehicle loan derived class");
            }
            public override int payEMI(int amount)
            {
                a = loanamt / duration + amount * (rate / 100);
                return a;
            }

            public override int getpendingloan()
            {
                int rem = loanamt - a;
                return rem;
            }
        }
}

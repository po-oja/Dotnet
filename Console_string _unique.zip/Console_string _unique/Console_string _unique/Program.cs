﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_string__unique
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "pooja";
            char[] ch = s.ToCharArray();
            bool flag = true;
            
                for (int i = 0; i < ch.Length; i++)
                {
                    for (int j = i + 1; j < ch.Length; j++)
                    {
                        if (ch[i] == ch[j])
                        {
                            flag = false;
                            break;
                        }

                    }
                }
            

                if (flag == true)
                {
                    Console.WriteLine("unique word");

                }
                else
                {
                    Console.WriteLine("not unique word");
                }
            
            Console.ReadLine();





        }
    }
}

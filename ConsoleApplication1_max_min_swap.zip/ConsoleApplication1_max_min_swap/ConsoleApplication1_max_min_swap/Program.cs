﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1_max_min_swap
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] m = { 21, 34, 56, 78, 12 };
            for(int i=0;i<m.Length;i++)
            {
                Console.WriteLine(m[i]);
            }
            int max = m[0];
            int min = m[0];
            for(int t=0;t<m.Length;t++)
            {
                if(m[t]>max)
                {
                    max = m[t];
                }
                if(m[t]<min)
                {
                    min = m[t];
                }
            }
            Console.WriteLine("max=" + max.ToString());
            Console.WriteLine("min=" + min.ToString());
            int temp = m[0];
            m[0] = m[m.Length - 1];
            m[m.Length - 1] = temp;

           for(int k=0;k<m.Length;k++)
            {
                Console.WriteLine(m[k]);
            }
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee_info
{
    class employee
    {
        private int employeeID;
        private string employeeName;
        private int employeeAge;
        private int employeesalary;
        public employee(int empid,string empname,int empage,int empsalary)
        {
            this.employeeID = empid;
            this.employeeName = empname;
            this.employeeAge = empage;
            this.employeesalary = empsalary;
        }
        public int Getid()
        {
            return this.employeeID;
        }
        public string Getname()
        {
            return this.employeeName;

        }
        public int Getage()
        {
            return this.employeeAge;

        }
        public int Getsalary()
        {
            return this.employeesalary;
        }
        public void Gethappybirth()// on birthday only 1 year will be incresed
        {
            employeeAge = employeeAge + 1;
           // return employeeAge;
        }
        public void Getincrement(int amount)// salary +incremented amount 
        {
            employeesalary = employeesalary + amount;
            //return employeesalary;
        }

    }
}

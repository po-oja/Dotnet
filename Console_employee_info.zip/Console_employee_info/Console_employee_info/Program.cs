﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee_info
{
    class Program
    {
        static void Main(string[] args)
        {
            employee obj = new employee(123, "pooja", 22, 20000);//constructor 
            int id = obj.Getid();
            string name = obj.Getname();
            int age = obj.Getage();
            int salary = obj.Getsalary();
            Console.WriteLine("employee ID=" + id);
            Console.WriteLine("employee name=" + name);
            Console.WriteLine("employee age=" + age);
            Console.WriteLine("employee salary=" + salary);
            obj.Gethappybirth();
            age = obj.Getage();
            obj.Getincrement(5000);
            salary = obj.Getsalary();
            Console.WriteLine("The current age of an employee=" + age);
            Console.WriteLine("increment in the salary=" + salary);
            Console.ReadLine();
            


        }
    }
}

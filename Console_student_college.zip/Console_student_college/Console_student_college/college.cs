﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_student_college
{
    class college
    {
        public void leavenotification(int studentid,string reason)
        {
            Console.WriteLine("college portal :student on leave ,id:" + studentid + "reason" + reason);
        }

       private int collegeid;
        private string collegename;
        private List<student> studentlist = new List<student>();



        public college(int collegeid,string collegename)
        {
            this.collegeid = collegeid;
            this.collegename = collegename;
        }
        public int pcid { get { return this.collegeid; } }
        public string pcname { get { return this.collegename; } }


        public void addstudent(student obj)
        {
            this.studentlist.Add(obj);
            obj.evtleave += new student.delleave(this.leavenotification);
        }
        public student findstudent(int id)
        {
            foreach(student s in studentlist)
            {
                if(s.pid==id)
                {
                    return s;
                }
            }
            return null;
        }
        public bool remove(int id)
        {
            foreach(student s in studentlist)
            {
                if(s.pid==id)
                {
                    this.studentlist.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public void showall()
        {
            foreach(student s in this.studentlist)
            {
                Console.WriteLine("student id:" + s.pid + "\t student name :"+s.pname);
            }
        }


    }
}

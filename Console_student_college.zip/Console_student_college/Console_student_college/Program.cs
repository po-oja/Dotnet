﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_student_college
{
    class Program
    {
        static void Main(string[] args)
        {
            college cobj = new college(1010, "cit");
            Console.WriteLine("college id:" + cobj.pcid);
            Console.WriteLine("college name:" + cobj.pcname);

            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1=add,2=find 3=showall ,4=remove,5= leave,6= exit");
                int opt =Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        {
                            Console.WriteLine("enter the studentname:");
                            string name = Console.ReadLine();
                            Console.WriteLine("enter the student email");
                            string email = Console.ReadLine();
                            student s = new student(name, email);
                            cobj.addstudent(s);
                            Console.WriteLine("student id:" + s.pid);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the student id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            student s = cobj.findstudent(id);
                            if (s != null)
                            {
                                Console.WriteLine(s.pid + "  " + s.pname + "  " + s.pemail);
                            }
                            else
                            {
                                Console.WriteLine("not found");
                            }
                            break;
                        }
                            case 3:
                        {
                            cobj.showall();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("student id");
                            int id1 = Convert.ToInt32(Console.ReadLine());
                            bool status = cobj.remove(id1);
                            if(status==true)
                            {
                                Console.WriteLine("removed successfulluy");
                            }
                            else
                            {
                                Console.WriteLine("not found");
                            }
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("enter the student id ");
                            int id2 = Convert.ToInt32(Console.ReadLine());
                            student s = cobj.findstudent(id2);
                            if(s!=null)
                            {
                                Console.WriteLine("enter the laeve reason ");
                                string reason = Console.ReadLine();
                                s.requestleave(reason);

                            }
                            else
                            {
                                Console.WriteLine("not found");
                            }
                            break;

                        }
                    case 6:
                        { flag = false;
                            break;
                        }
                        
                }
            }



            Console.ReadLine();
        }
    }
}

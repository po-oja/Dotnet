﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_student_college
{
    class student
    {

        public delegate void delleave(int studentid, string msg);
        public event delleave evtleave;//member of class(object member)
        protected int studentid;
        protected string studentname;
        protected string studentemail;
        private static int count;
         public student(string studentname,string studentemail)
        {
            this.studentid = ++student.count;
            this.studentname = studentname;
            this.studentemail = studentemail;
        }
        public int pid { get { return this.studentid; } }
        public string pname { get { return this.studentname; } }
        public string pemail { get { return this.studentemail; } }
        
        public void requestleave(string leavereason)
        {
            Console.WriteLine("student requestin for a leave " + leavereason);
            if(this.evtleave!=null)
            {
                this.evtleave(this.studentid, leavereason);
            }
        } 


    }
}

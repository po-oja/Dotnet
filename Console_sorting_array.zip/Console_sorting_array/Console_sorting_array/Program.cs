﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_sorting_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = new int[20];
            int i, j, temp;
            Console.WriteLine("sorting elements in the array");
            Console.WriteLine("Enter the size of the elements");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the elements in array");
            for(i=0;i<n;i++)
            {
                arr1[i] = Convert.ToInt32(Console.ReadLine());
            }

            for(i=0;i<n;i++)
            {
                for(j=i+1;j<n;j++)
                {
                    if(arr1[j]<arr1[i])
                    {
                        temp = arr1[i];
                        arr1[i] = arr1[j];
                        arr1[j] = temp;
                    }
                }
            }

            Console.WriteLine("The sorted elements in array is");
            for(i=0;i<n;i++)
            {
                Console.WriteLine(arr1[i]);
            }

            Console.ReadLine();

        }
    }
}

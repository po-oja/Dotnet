﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado_emp
{
    public partial class Frm_find : Form
    {
        public Frm_find()
        {
            InitializeComponent();
        }

        private void ddl_city_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Frm_find_Load(object sender, EventArgs e)
        {
            ddl_city.Items.Add("BGL");
            ddl_city.Items.Add("Chennai");
            ddl_city.Items.Add("tumkur");
        }

        private void btn_finemp_Click(object sender, EventArgs e)
        {
            if(txt_empid.Text==string.Empty)
            {
                lbl_status.Text = "enter the employee ID";
            }
            else
            {
                int id = Convert.ToInt32(txt_empid.Text);
                employeeDAL dal = new employeeDAL();
                employeeModel model = dal.find(id);
                if(model!=null)
                {
                    txt_empname.Text = model.employeename;
                    txt_empsalary.Text = model.employeesalary.ToString();
                    ddl_city.Text = model.employeecity;
                    txt_empdoj.Text = model.employeeDOJ.ToString();
                }
                else
                {
                    lbl_status.Text = "employee not found";
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_empid.Text);
            string city = ddl_city.Text;
            int salary = Convert.ToInt32(txt_empsalary.Text);
            employeeDAL dal = new employeeDAL();
            bool status= dal.updateemployee(id, city, salary);
            if (status == true)
            {
                lbl_status.Text = "employee update";
            }
            else
            {
                lbl_status.Text = "not found";
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txt_empid.Text);
            employeeDAL dal = new employeeDAL();
            bool status = dal.deleteemployee(id);
            if(status==true)
            {
                lbl_status.Text = "Deleted";
            }
            else
            {
                lbl_status.Text = "not deleted";
            }
        }
    }
}

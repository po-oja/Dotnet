﻿namespace Win_ado_emp
{
    partial class Frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_empid = new System.Windows.Forms.Label();
            this.lbl_empname = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_empsalary = new System.Windows.Forms.Label();
            this.txt_empid = new System.Windows.Forms.TextBox();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_empsalary = new System.Windows.Forms.TextBox();
            this.btn_finemp = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.ddl_city = new System.Windows.Forms.ComboBox();
            this.lbl_status = new System.Windows.Forms.Label();
            this.lbl_empdoj = new System.Windows.Forms.Label();
            this.txt_empdoj = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empid.Location = new System.Drawing.Point(118, 31);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(118, 24);
            this.lbl_empid.TabIndex = 0;
            this.lbl_empid.Text = "Employee ID";
            // 
            // lbl_empname
            // 
            this.lbl_empname.AutoSize = true;
            this.lbl_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empname.Location = new System.Drawing.Point(121, 73);
            this.lbl_empname.Name = "lbl_empname";
            this.lbl_empname.Size = new System.Drawing.Size(152, 24);
            this.lbl_empname.TabIndex = 1;
            this.lbl_empname.Text = "Employee Name";
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empcity.Location = new System.Drawing.Point(124, 111);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(131, 24);
            this.lbl_empcity.TabIndex = 2;
            this.lbl_empcity.Text = "Employee City";
            // 
            // lbl_empsalary
            // 
            this.lbl_empsalary.AutoSize = true;
            this.lbl_empsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empsalary.Location = new System.Drawing.Point(127, 154);
            this.lbl_empsalary.Name = "lbl_empsalary";
            this.lbl_empsalary.Size = new System.Drawing.Size(149, 24);
            this.lbl_empsalary.TabIndex = 3;
            this.lbl_empsalary.Text = "Employee salary";
            // 
            // txt_empid
            // 
            this.txt_empid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empid.Location = new System.Drawing.Point(308, 31);
            this.txt_empid.Name = "txt_empid";
            this.txt_empid.Size = new System.Drawing.Size(122, 29);
            this.txt_empid.TabIndex = 4;
            // 
            // txt_empname
            // 
            this.txt_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empname.Location = new System.Drawing.Point(308, 73);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(122, 29);
            this.txt_empname.TabIndex = 5;
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(464, 243);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(97, 42);
            this.btn_delete.TabIndex = 10;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // txt_empsalary
            // 
            this.txt_empsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empsalary.Location = new System.Drawing.Point(308, 154);
            this.txt_empsalary.Name = "txt_empsalary";
            this.txt_empsalary.Size = new System.Drawing.Size(122, 29);
            this.txt_empsalary.TabIndex = 7;
            // 
            // btn_finemp
            // 
            this.btn_finemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_finemp.Location = new System.Drawing.Point(538, 27);
            this.btn_finemp.Name = "btn_finemp";
            this.btn_finemp.Size = new System.Drawing.Size(122, 60);
            this.btn_finemp.TabIndex = 8;
            this.btn_finemp.Text = "Find Employee";
            this.btn_finemp.UseVisualStyleBackColor = true;
            this.btn_finemp.Click += new System.EventHandler(this.btn_finemp_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(203, 252);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(110, 42);
            this.btn_update.TabIndex = 9;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // ddl_city
            // 
            this.ddl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_city.FormattingEnabled = true;
            this.ddl_city.Location = new System.Drawing.Point(309, 116);
            this.ddl_city.Name = "ddl_city";
            this.ddl_city.Size = new System.Drawing.Size(121, 32);
            this.ddl_city.TabIndex = 11;
            this.ddl_city.SelectedIndexChanged += new System.EventHandler(this.ddl_city_SelectedIndexChanged);
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_status.Location = new System.Drawing.Point(122, 310);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(151, 24);
            this.lbl_status.TabIndex = 12;
            this.lbl_status.Text = "Employee Status";
            // 
            // lbl_empdoj
            // 
            this.lbl_empdoj.AutoSize = true;
            this.lbl_empdoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empdoj.Location = new System.Drawing.Point(127, 195);
            this.lbl_empdoj.Name = "lbl_empdoj";
            this.lbl_empdoj.Size = new System.Drawing.Size(138, 24);
            this.lbl_empdoj.TabIndex = 13;
            this.lbl_empdoj.Text = "Employee DOJ";
            // 
            // txt_empdoj
            // 
            this.txt_empdoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empdoj.Location = new System.Drawing.Point(308, 195);
            this.txt_empdoj.Name = "txt_empdoj";
            this.txt_empdoj.Size = new System.Drawing.Size(122, 29);
            this.txt_empdoj.TabIndex = 14;
            // 
            // Frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 357);
            this.Controls.Add(this.txt_empdoj);
            this.Controls.Add(this.lbl_empdoj);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.ddl_city);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_finemp);
            this.Controls.Add(this.txt_empsalary);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.txt_empid);
            this.Controls.Add(this.lbl_empsalary);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_empname);
            this.Controls.Add(this.lbl_empid);
            this.Name = "Frm_find";
            this.Text = "Frm_find";
            this.Load += new System.EventHandler(this.Frm_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.Label lbl_empname;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_empsalary;
        private System.Windows.Forms.TextBox txt_empid;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_empsalary;
        private System.Windows.Forms.Button btn_finemp;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.ComboBox ddl_city;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.Label lbl_empdoj;
        private System.Windows.Forms.TextBox txt_empdoj;
    }
}
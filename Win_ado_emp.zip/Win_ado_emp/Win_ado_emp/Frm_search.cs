﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado_emp
{
    public partial class Frm_search : Form
    {
        public Frm_search()
        {
            InitializeComponent();
        }

        private void lbl_empid_Click(object sender, EventArgs e)
        {

        }

        private void btn_searchemp_Click(object sender, EventArgs e)
        {
            employeeDAL dal = new employeeDAL();
            string key = txt_key.Text;
            List<employeeModel> list = dal.search(key);
            dg_employees.DataSource = list;

        }
    }
}

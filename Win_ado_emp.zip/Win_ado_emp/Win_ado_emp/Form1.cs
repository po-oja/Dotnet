﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado_emp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_login.Text == string.Empty)
            {
                lbl_loginstatus.Text = "enter login ID";

            }
            else if (txt_password.Text == string.Empty)
            {
                lbl_loginstatus.Text = "enter password";
            }
            else
            {
                int loginid = Convert.ToInt32 (txt_login.Text);
                string password = txt_password.Text;
                employeeDAL dal = new employeeDAL();
                bool status = dal.login(loginid, password);
                if(status==true)
                {
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    lbl_loginstatus.Text = "inavlid user ID and password";
                }

            }
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            Frm_newuser obj = new Frm_newuser();
            obj.Show();
        }
       
          

    }
}
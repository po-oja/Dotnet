﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;//DLL ref
using System.Data;//ADO.net
using System.Data.SqlClient;//database connective

namespace Win_ado_emp
{
    class employeeDAL
    {
        SqlConnection con = new SqlConnection
       (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int addemployee(employeeModel model)
        {
            try
            {
                SqlCommand com_addemployee = new SqlCommand("proc_addemployee", con);
                com_addemployee.CommandType = CommandType.StoredProcedure;
                com_addemployee.Parameters.AddWithValue("@name", model.employeename);
                com_addemployee.Parameters.AddWithValue("@password", model.employeepassword);
                com_addemployee.Parameters.AddWithValue("@city", model.employeecity);
                com_addemployee.Parameters.AddWithValue("@salary", model.employeesalary);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addemployee.Parameters.Add(para_return);
                con.Open();
                com_addemployee.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;



            }
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


        public bool login(int id,string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.CommandType = CommandType.StoredProcedure;
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@password", password);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(para_return);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
            }
        
        public bool updateemployee(int id,string city,int salary)
        {
            try
            {

                SqlCommand com_update = new SqlCommand("proc_update", con);
                com_update.CommandType = CommandType.StoredProcedure;
                com_update.Parameters.AddWithValue("@id", id);
                com_update.Parameters.AddWithValue("@city", city);
                com_update.Parameters.AddWithValue("@salary", salary);

                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_update.Parameters.Add(para_return);
                con.Open();
                com_update.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


        public bool deleteemployee(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_delete", con);
                com_delete.CommandType = CommandType.StoredProcedure;
                com_delete.Parameters.AddWithValue("@id", id);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(para_return);
                con.Open();
                com_delete.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if(count>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public employeeModel find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findemp", con);
                com_find.CommandType = CommandType.StoredProcedure;
                com_find.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if(dr.Read())
                {
                    employeeModel model = new employeeModel();
                    model.employeeid = dr.GetInt32(0);
                    model.employeename = dr.GetString(1);
                    model.employeepassword = dr.GetString(2);
                    model.employeecity = dr.GetString(3);
                    model.employeesalary = dr.GetInt32(4);
                    model.employeeDOJ = dr.GetDateTime(5);
                    con.Close();
                    return model;

                }
                con.Close();
                return null;
            }
            finally
            {
                 
            if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                
            }
        }

        public List<employeeModel> search(string key)
        {
            try
            {
                SqlCommand com_search = new SqlCommand("proc_searchemp", con);
                com_search.CommandType = CommandType.StoredProcedure;
                com_search.Parameters.AddWithValue("@key", key);
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<employeeModel> emplist = new List<employeeModel>();
                while (dr.Read())
                {
                    employeeModel model = new employeeModel();
                    model.employeeid = dr.GetInt32(0);
                    model.employeename = dr.GetString(1);
                    model.employeepassword = dr.GetString(2);
                    model.employeecity = dr.GetString(3);
                    model.employeesalary = dr.GetInt32(4);
                    model.employeeDOJ = dr.GetDateTime(5);
                    emplist.Add(model);
                }
                con.Close();
                return emplist;
            }
            finally
            {
              

                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                
            }
        }



    }
}

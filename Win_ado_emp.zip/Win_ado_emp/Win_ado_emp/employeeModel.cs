﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_ado_emp
{
    class employeeModel
    {
        public int employeeid { get; set; }
         public string employeename { get; set; }
        public string employeepassword { get; set; }
        public string employeecity { get; set; }
        public int employeesalary { get; set; }
        public DateTime employeeDOJ { get; set; }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado_emp
{
    public partial class Frm_newuser : Form
    {
        public Frm_newuser()
        {
            InitializeComponent();
        }

        private void Frm_newuser_Load(object sender, EventArgs e)
        {
            ddl_city.Items.Add("BGL");
            ddl_city.Items.Add("chennai");
            ddl_city.Items.Add("tumkur");
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if(txt_empname.Text==string.Empty)
            {
                lbl_empid.Text = "enter valid name";
            }
            else if(txt_emppassword.Text==string.Empty)
            {
                lbl_empid.Text = "enter password";
            }
            else if(ddl_city.Text==string.Empty)
            {
                lbl_empid.Text = "select valid city";
            }
            else if(txt_empsalary.Text==string.Empty)
            {
                lbl_empid.Text = "enter salary";
            }

            else
            {
                employeeModel model = new employeeModel();
                model.employeename = txt_empname.Text;
                model.employeepassword = txt_emppassword.Text;
                model.employeecity = ddl_city.Text;
                model.employeesalary = Convert.ToInt32(txt_empsalary.Text);
                employeeDAL dal = new employeeDAL();
                int id = dal.addemployee(model);
                lbl_empid.Text = "employee added,ID" + id;
            }




        }
    }
}

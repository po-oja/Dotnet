﻿namespace Win_ado_emp
{
    partial class Frm_newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_empcity = new System.Windows.Forms.Label();
            this.lbl_empsalry = new System.Windows.Forms.Label();
            this.txt_empname = new System.Windows.Forms.TextBox();
            this.txt_emppassword = new System.Windows.Forms.TextBox();
            this.txt_empsalary = new System.Windows.Forms.TextBox();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.ddl_city = new System.Windows.Forms.ComboBox();
            this.lbl_empid = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(192, 39);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(152, 24);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "Employee Name";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(195, 77);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(183, 24);
            this.lbl_password.TabIndex = 1;
            this.lbl_password.Text = "Employee Password";
            // 
            // lbl_empcity
            // 
            this.lbl_empcity.AutoSize = true;
            this.lbl_empcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empcity.Location = new System.Drawing.Point(198, 115);
            this.lbl_empcity.Name = "lbl_empcity";
            this.lbl_empcity.Size = new System.Drawing.Size(131, 24);
            this.lbl_empcity.TabIndex = 2;
            this.lbl_empcity.Text = "Employee City";
            // 
            // lbl_empsalry
            // 
            this.lbl_empsalry.AutoSize = true;
            this.lbl_empsalry.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empsalry.Location = new System.Drawing.Point(201, 159);
            this.lbl_empsalry.Name = "lbl_empsalry";
            this.lbl_empsalry.Size = new System.Drawing.Size(152, 24);
            this.lbl_empsalry.TabIndex = 3;
            this.lbl_empsalry.Text = "Employee Salary";
            // 
            // txt_empname
            // 
            this.txt_empname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empname.Location = new System.Drawing.Point(363, 39);
            this.txt_empname.Name = "txt_empname";
            this.txt_empname.Size = new System.Drawing.Size(147, 29);
            this.txt_empname.TabIndex = 4;
            // 
            // txt_emppassword
            // 
            this.txt_emppassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emppassword.Location = new System.Drawing.Point(405, 77);
            this.txt_emppassword.Name = "txt_emppassword";
            this.txt_emppassword.Size = new System.Drawing.Size(147, 29);
            this.txt_emppassword.TabIndex = 5;
            // 
            // txt_empsalary
            // 
            this.txt_empsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_empsalary.Location = new System.Drawing.Point(373, 159);
            this.txt_empsalary.Name = "txt_empsalary";
            this.txt_empsalary.Size = new System.Drawing.Size(147, 29);
            this.txt_empsalary.TabIndex = 7;
            // 
            // btn_newuser
            // 
            this.btn_newuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newuser.Location = new System.Drawing.Point(233, 227);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(122, 35);
            this.btn_newuser.TabIndex = 8;
            this.btn_newuser.Text = "New User";
            this.btn_newuser.UseVisualStyleBackColor = true;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            // 
            // ddl_city
            // 
            this.ddl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_city.FormattingEnabled = true;
            this.ddl_city.Location = new System.Drawing.Point(374, 115);
            this.ddl_city.Name = "ddl_city";
            this.ddl_city.Size = new System.Drawing.Size(168, 32);
            this.ddl_city.TabIndex = 9;
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empid.Location = new System.Drawing.Point(233, 284);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(128, 24);
            this.lbl_empid.TabIndex = 10;
            this.lbl_empid.Text = "Employee ID :";
            // 
            // Frm_newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 328);
            this.Controls.Add(this.lbl_empid);
            this.Controls.Add(this.ddl_city);
            this.Controls.Add(this.btn_newuser);
            this.Controls.Add(this.txt_empsalary);
            this.Controls.Add(this.txt_emppassword);
            this.Controls.Add(this.txt_empname);
            this.Controls.Add(this.lbl_empsalry);
            this.Controls.Add(this.lbl_empcity);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_name);
            this.Name = "Frm_newuser";
            this.Text = "Frm_newuser";
            this.Load += new System.EventHandler(this.Frm_newuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_empcity;
        private System.Windows.Forms.Label lbl_empsalry;
        private System.Windows.Forms.TextBox txt_empname;
        private System.Windows.Forms.TextBox txt_emppassword;
        private System.Windows.Forms.TextBox txt_empsalary;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.ComboBox ddl_city;
        private System.Windows.Forms.Label lbl_empid;
    }
}
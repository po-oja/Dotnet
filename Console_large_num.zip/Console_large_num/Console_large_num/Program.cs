﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_large_num
{
    class Program
    {
        static void Main(string[] args)
        {
            int largenum;
            int[] a = new int[10];
            largenum = a[0];

            Console.WriteLine("Enter the elements in array");
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] > largenum)
                {
                    largenum = a[i];
                }
            }
            Console.WriteLine("the largest element is " + largenum);
            Console.ReadLine();
        }
    }
}

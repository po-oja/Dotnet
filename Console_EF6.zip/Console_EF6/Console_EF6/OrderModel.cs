﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Console_EF6
{
    [Table("tbl_orders")]
    class OrderModel

    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int orderid { get; set; }
        [Required]
        public int customerid { get; set; }
        [Required]
        public string itemname { get; set; }
        [Required]
        public int itemqty { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime orderdate { get; set; }

        [ForeignKey("customerid")]
        public CustomerModel customer { get; set; }//one customer for one order
    }
}

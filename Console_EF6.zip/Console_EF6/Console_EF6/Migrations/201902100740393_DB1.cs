namespace Console_EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DB1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tbl_customers",
                c => new
                    {
                        customerid = c.Int(nullable: false, identity: true),
                        customerFullName = c.String(nullable: false, maxLength: 100),
                        customercity = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.customerid);
            
            CreateTable(
                "dbo.tbl_orders",
                c => new
                    {
                        orderid = c.Int(nullable: false, identity: true),
                        customerid = c.Int(nullable: false),
                        itemname = c.String(nullable: false),
                        itemqty = c.Int(nullable: false),
                        orderdate = c.DateTime(nullable: false,defaultValueSql:"getdate()"),
                    })
                .PrimaryKey(t => t.orderid)
                .ForeignKey("dbo.tbl_customers", t => t.customerid, cascadeDelete: true)
                .Index(t => t.customerid);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.tbl_orders", "customerid", "dbo.tbl_customers");
            DropIndex("dbo.tbl_orders", new[] { "customerid" });
            DropTable("dbo.tbl_orders");
            DropTable("dbo.tbl_customers");
        }
    }
}

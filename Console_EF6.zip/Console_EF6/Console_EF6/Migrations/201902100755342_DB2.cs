namespace Console_EF6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DB2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tbl_customers", "customeremail", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tbl_customers", "customeremail");
        }
    }
}

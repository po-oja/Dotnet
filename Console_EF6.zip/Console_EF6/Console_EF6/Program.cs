﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_EF6
{
    class Program
    {
        static void Main(string[] args)
        {
            MyDbContext dc = new MyDbContext();
            /*
              CustomerModel model = new CustomerModel();
              model.customername = "pankaja";
              model.customercity = "Tumkur";
              model.customeremail = "pankaja@gmail.com";
              dc.customers.Add(model);
              dc.SaveChanges();
              Console.WriteLine("customer is added" + model.customerid);

            */
            //find
            // CustomerModel model = (from c in dc.customers
            // where c.customerid == 1
            // select c).FirstOrDefault();//lINQ

            /*
            CustomerModel model = dc.customers.FirstOrDefault(c => c.customerid == 2);

            if (model!=null)
            {
                Console.WriteLine(model.customerid + " " + model.customername);
                //dc.customers.Remove(model);
               // model.customercity = "pune";
               // dc.SaveChanges();
               // Console.WriteLine("deleted");
            }
            else
            {
                Console.WriteLine("not found");
            }*/

            var count = dc.customers.Count(c => c.customerid == 2 && c.customercity == "tumkur");
            
            Console.WriteLine(count);

            var list1 = (from c in dc.customers
                         where c.customercity == "tumkur"
                         select c).ToList();

            var list2 = dc.customers.Where(c => c.customercity == "tumkur").ToList();
            string key = "BGL";
            var list3 = dc.customers.Where(c => c.customercity.Contains(key)||c.customeremail.Contains(key)).ToList();

            foreach (CustomerModel m in list2)
            {
                Console.WriteLine(m.customerid + " " + m.customername);
            }
            

            Console.ReadLine();


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Console_EF6
{
    class MyDbContext:DbContext
    {
        public MyDbContext() : base("constr") { }

        public DbSet<CustomerModel> customers { get; set; }
        public DbSet<OrderModel> orders { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Console_EF6
{
    [Table("tbl_customers")]
    class CustomerModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int customerid { get; set; }

        [Required]
        [StringLength(100)]
        [Column("customerFullName")]
        public string customername { get; set; }

        [Required]
        [StringLength(100)]
        
        public string customercity { get; set; }
      
   
     
        [Required]
        public string customeremail { get; set; }
        [NotMapped]
        public string customerdetails { get; set; }


        public List<OrderModel> orders { get; set; }//customer can have any number of orders
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_small_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int smallnum;
           int[] a = new int[10];
            smallnum = a[0];
         
            Console.WriteLine("Enter the elements in array");
            for(int i=0;i<a.Length;i++)
            {
                if(a[i]<smallnum)
                {
                    smallnum = a[i];
                }
            }



            Console.ReadLine();
        }
    }
}

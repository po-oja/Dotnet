﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_swap_num
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the value of a");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the value of b");
            int b= Convert.ToInt32(Console.ReadLine());

            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine("The value of swapped numbers are");
            Console.WriteLine("a="+a);
            Console.WriteLine("b="+b);
            Console.ReadLine();


        }
    }
}

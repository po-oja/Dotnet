﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_second_largenum
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
           int larnum = a[0];
            int secnum = a[0];
            Console.WriteLine("enter the size of the array");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the elements in the array");
            for(int i=0;i<n;i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
                if(a[i]>larnum)
                {
                    secnum = larnum;
                    larnum = a[i];

                }

                else if(a[i]>secnum)
                {
                    secnum = a[i];
                }

            }
            Console.WriteLine("second largest number is" + secnum);


            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_order_items
{
    class Program
    {
        static void Main(string[] args)
        {
            order obj = new order(1, "pooja", 5, "rice", 2000);
            int id = obj.getid();
            string name = obj.getname();
            int qty = obj.getitemqty();
            string itemname = obj.getitemname();
            int price = obj.getprice();
            Console.WriteLine("order id =" + id);
            Console.WriteLine("customer name =" + name);
            Console.WriteLine("order Quatity =" + qty);
            Console.WriteLine("order itemname =" + itemname);
            Console.WriteLine("ordered price =" + price);
            int total=obj.orderamount();
            Console.WriteLine("Total amount =" + total);
            obj.updateqty(10);
            total = obj.orderamount();
            qty = obj.getitemqty();
            Console.WriteLine("number of items in total is " + qty);
            Console.WriteLine("The updated item quantity total=" + total);

            Console.ReadLine();
        }
    }
}

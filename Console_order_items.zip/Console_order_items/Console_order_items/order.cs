﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_order_items
{
    class order
    {
        private int orderID;
        private string customerName;
        private int itemQuantity;
        private string itemName;
        private int itemPrice;
        

        public order(int ordid,string customername,int itmqty,string itmname,int price)
        {
            this.orderID = ordid;
            this.customerName= customername;
            this.itemQuantity = itmqty;
            this.itemName = itmname;
            this.itemPrice = price;
        }
        public int getid()
        {
            return this.orderID;

        }
        public string getname()
        {
            return this.customerName;
        }
        public string getitemname()
        {
            return this.itemName;
        }
        public int getitemqty()
        {
            return this.itemQuantity;
        }
        public int getprice()
        {
            return this.itemPrice;
        }
        public int orderamount()//total amount
        {
            int total = itemQuantity * itemPrice;//number of items*price of each item
            return total;
        }
        public void updateqty(int n)
        {
            itemQuantity =  n;//quantity may be incremented or decremented
           
        }
    }
}

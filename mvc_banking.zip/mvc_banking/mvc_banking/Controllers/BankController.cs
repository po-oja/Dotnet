﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_banking.Controllers
{
    public class BankController : Controller
    {
        [HttpGet]
        public ActionResult Login()
        {
            List<SelectListItem> logintypes = new List<SelectListItem>();
            logintypes.Add(new SelectListItem { Text = "select", Value = "" });
            logintypes.Add(new SelectListItem { Text = "Customer", Value = "Customer" });
            logintypes.Add(new SelectListItem { Text = "Employee", Value = "Employee" });
            ViewBag.logintypes = logintypes;
            return View();
        }
        [HttpPost]
        public ActionResult Login(string LoginID, string password, string LoginType)
        {
            if (LoginID == "user1" && password == "1234")
            {
                Session["LoginID"] = LoginID;
                return RedirectToAction("Index", "Home");

            }
            else
            {
                ViewBag.msg = "Inavlid ID Or password";
                List<SelectListItem> logintypes = new List<SelectListItem>();
                logintypes.Add(new SelectListItem { Text = "select", Value = "" });
                logintypes.Add(new SelectListItem { Text = "Customer", Value = "Customer" });
                logintypes.Add(new SelectListItem { Text = "Employee", Value = "Employee" });
                ViewBag.logintypes = logintypes;
                return View();

            }
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View();

        }
       
        
        [HttpPost]
        public ActionResult NewUser(string EmailID,string password,string FirstName,string LastName,string City,string Gender,HttpPostedFileBase image)
        {


            

            string address = "/Images/" + Guid.NewGuid() + ".jpg";
            image.SaveAs(Server.MapPath(address));
            
            ViewBag.address = address;
            return View();
        }
        [HttpGet]
        public ActionResult NewUser()
        {
            List<SelectListItem> City = new List<SelectListItem>();
            City.Add(new SelectListItem { Text = "select", Value = "" });
            City.Add(new SelectListItem { Text = "BGL", Value = "BGL" });
            City.Add(new SelectListItem { Text = "Chennai", Value = "Chennai" });
            ViewBag.City = City;
            return View();
        }
    }
}
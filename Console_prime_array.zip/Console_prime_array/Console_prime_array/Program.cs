﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_prime_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, p;
            int[] arr = new int[10];
            Console.WriteLine("Enter the size of the array");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the array elements");
            for(i=0;i<n;i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("the prime number in the given array are");
            for(i=0;i<n;i++)
            {
                p = 1;
                if (arr[i] == 1)
                {
                    p = 0;
                    break;
                }

                for (j = 2; j <= (arr[i] / 2); j++)
            {
                    //j = 2;
                   
                if (arr[i] % j == 0 )
                {
                    p = 0;
                    break;
                }
                //j++;
            }
                
                if(p==1)
                {
                    Console.WriteLine(+arr[i]);
                }
            }


            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_string__duplicate
{
    class Program
    {
        static void Main(string[] args)
        {

            string s = "HELLO DOTNET";
            char[] c = s.ToCharArray();

            for (int i = 0; i < c.Length; i++)
            {
                for (int j = i + 1; j < c.Length; j++)
                {
                    if(c[i]==c[j])
                    {
                        Console.WriteLine(c[i]);
                        break;
                    }

                }

            }

            Console.ReadLine();







        }
    }
}

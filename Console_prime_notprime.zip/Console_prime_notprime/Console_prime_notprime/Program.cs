﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_prime_notprime
{
    class Program
    {
        static void Main(string[] args)
        {
            int m = 0, i=2, flag = 0;
            Console.WriteLine("Enter the number");
            int a = Convert.ToInt32(Console.ReadLine());
            m = a / 2;
            //for(i=2;i<=m;i++)
            //{
                if(a%i==0)
                {
                    Console.WriteLine("number is not a prime number");
                i++;
                    flag = 1;

                   
                }
           // }
            if(flag==0)
            {
                Console.WriteLine("the number is a prime number");
            }

            Console.ReadLine();
        }
    }
}
